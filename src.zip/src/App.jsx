import { Routes, Route } from "react-router-dom";
import Home from "./Pages/Home";
import People from "./Pages/People";
import Layout from "./Pages/Layout";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="home" element={<Home />} />
        <Route path="directory" element={<People />} />
      </Route>
    </Routes>
  );
}

export default App;
