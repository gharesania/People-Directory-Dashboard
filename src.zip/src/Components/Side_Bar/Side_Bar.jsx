import { NavLink } from "react-router-dom";
import "./Side_Bar.css";
import { LayoutDashboard, Users } from "lucide-react";

const Side_Bar = () => {
  return (
    <div className="sidebar-container d-flex flex-column p-3">
      <ul className="list-unstyled m-0">
        <li className="mb-2">
          <NavLink
            to="/home"
            style={({ isActive }) => ({
              color: isActive ? "#6A37C4" : "black",
              textDecoration: "none",
            })}
          >
            <LayoutDashboard className="me-2" size={18} />
            Overview
          </NavLink>
        </li>

        <li>
          <NavLink
            to="/directory"
            style={({ isActive }) => ({
              color: isActive ? "#6A37C4" : "black",
              textDecoration: "none",
            })}
          >
            <Users className="me-2" size={18} />
            People Directory
          </NavLink>
        </li>
      </ul>
    </div>
  );
};

export default Side_Bar;
