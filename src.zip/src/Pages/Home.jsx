import { useEffect, useState } from "react";
import "./Home.css";
import { Card, Spinner } from "react-bootstrap";
import axios from "axios";

const Home = () => {
  const API_URL = "https://68dcd02d7cd1948060ab6364.mockapi.io/users";

  const [userCount, setUserCount] = useState(0);
  const [loading, setLoading] = useState(true);

  // Fetch user count
  const fetchUserCount = async () => {
    try {
      setLoading(true);
      const res = await axios.get(API_URL);
      setUserCount(res.data.length);
    } catch (err) {
      console.error("Error fetching user count:", err);
    } finally {
      setLoading(false);
    }
  };

  // Call when component loads
  useEffect(() => {
    fetchUserCount();
  }, []);

  return (
    <div className="p-3">
      <h2 className="mb-4 fw-bold text-dark">Welcome, Jane Doe 👋</h2>

      <div className="row g-3">
        {/* Total Members */}
        <div className="col-md-4">
          <Card className="shadow-sm border-0 p-3 text-center">
            <h5 className="text-muted">Total Team Members</h5>
            <h2 className="fw-bold text-primary">{userCount}</h2>
          </Card>
        </div>

        {/* Active Projects */}
        <div className="col-md-4">
          <Card className="shadow-sm border-0 p-3 text-center">
            <h5 className="text-muted">Active Projects</h5>
            <h2 className="fw-bold text-success">7</h2>
          </Card>
        </div>

        {/* Pending Tasks */}
        <div className="col-md-4">
          <Card className="shadow-sm border-0 p-3 text-center">
            <h5 className="text-muted">Pending Tasks</h5>
            <h2 className="fw-bold text-warning">15</h2>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Home;
