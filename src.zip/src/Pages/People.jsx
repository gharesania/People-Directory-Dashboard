import axios from "axios";
import { Pen, Search, Trash, Filter } from "lucide-react";
import { useEffect, useState } from "react";
import {
  Button,
  Form,
  InputGroup,
  Table,
  Spinner,
  OverlayTrigger,
  Popover,
  Modal,
  Pagination,
  Badge,
} from "react-bootstrap";
import "./People.css";
import "../App.css";
import StatusBadge from "../Components/StatusBadge";
import FilterDropdown from "../Components/FilterDropdown/FilterDropdown.jsx";

const People = () => {
  const API_URL = "https://68dcd02d7cd1948060ab6364.mockapi.io/users";

  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  // Fetch Data
  async function getData() {
    try {
      setLoading(true);
      const res = await axios.get(API_URL);
      // Normalize data so teams is always an array
      const formatted = res.data.map((u) => ({
        ...u,
        teams: Array.isArray(u.teams)
          ? u.teams
          : u.teams
          ? [u.teams]
          : [],
      }));
      setData(formatted);
    } catch (err) {
      console.error("Error fetching data:", err);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    getData();
  }, []);

  // Modal States
  const [show, setShow] = useState(false);
  const [viewShow, setViewShow] = useState(false);
  const [deleteShow, setDeleteShow] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [editMode, setEditMode] = useState(false);

  // Search
  const [search, setSearch] = useState("");

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  // Form States
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [status, setStatus] = useState("");
  const [role, setRole] = useState("");
  const [teams, setTeams] = useState([]);
  const [gender, setGender] = useState("");

  // Reset Form
  const resetForm = () => {
    setName("");
    setEmail("");
    setUsername("");
    setStatus("");
    setRole("");
    setTeams([]);
    setGender("");
    setEditMode(false);
    setSelectedUser(null);
  };

  // Add or Edit User
  async function handleSave(e) {
    e.preventDefault();
    if (!name || !email || !username || !status || !role || teams.length === 0) {
      alert("Please fill all required fields.");
      return;
    }

    const userData = {
      name,
      email,
      username,
      status,
      role,
      teams,
      gender,
      profileURL
    };

    try {
      if (editMode && selectedUser) {
        const res = await axios.put(`${API_URL}/${selectedUser.id}`, userData);
        setData((prev) =>
          prev.map((u) => (u.id === selectedUser.id ? res.data : u))
        );
        alert("User updated successfully!");
      } else {
        const res = await axios.post(API_URL, userData);
        setData((prev) => [...prev, res.data]);
        alert("User added successfully!");
      }
      handleClose();
    } catch (err) {
      console.error("Error saving user:", err);
    }
  }

  // Delete User
  async function deleteUser(id) {
    try {
      await axios.delete(`${API_URL}/${id}`);
      setData((prev) => prev.filter((u) => u.id !== id));
      handleDeleteClose();
    } catch (err) {
      console.error("Error deleting user:", err);
    }
  }

  // --- Modal Control ---
  const handleClose = () => {
    setShow(false);
    resetForm();
  };
  const handleShow = () => setShow(true);

  const handleViewClose = () => setViewShow(false);
  const handleViewShow = (user) => {
    setSelectedUser(user);
    setViewShow(true);
  };

  const handleDeleteClose = () => setDeleteShow(false);
  const handleDeleteShow = (user) => {
    setSelectedUser(user);
    setDeleteShow(true);
  };

  const handleEditShow = (user) => {
    setSelectedUser(user);
    setEditMode(true);
    setName(user.name);
    setEmail(user.email);
    setUsername(user.username);
    setStatus(user.status);
    setRole(user.role);
    setTeams(user.teams || []);
    setGender(user.gender || "");
    handleShow();
  };

  // Filter By Role & Team
  const [selectedRole, setSelectedRole] = useState("");
  const [selectedTeam, setSelectedTeam] = useState("");

  // --- Filtering ---
  const filteredData = data.filter((user) => {
    const query = search.toLowerCase();

    const matchesSearch =
      user.name?.toLowerCase().includes(query) ||
      user.username?.toLowerCase().includes(query) ||
      user.email?.toLowerCase().includes(query) ||
      user.role?.toLowerCase().includes(query) ||
      (Array.isArray(user.teams)
        ? user.teams.some((team) => team.toLowerCase().includes(query))
        : user.teams?.toLowerCase().includes(query));

    const matchesRole = selectedRole
      ? user.role === selectedRole
      : true;

    const matchesTeam = selectedTeam
      ? Array.isArray(user.teams)
        ? user.teams.includes(selectedTeam)
        : user.teams === selectedTeam
      : true;

    return matchesSearch && matchesRole && matchesTeam;
  });

  // --- Pagination Logic ---
  const indexOfLast = currentPage * itemsPerPage;
  const indexOfFirst = indexOfLast - itemsPerPage;
  const currentUsers = filteredData.slice(indexOfFirst, indexOfLast);
  const totalPages = Math.ceil(filteredData.length / itemsPerPage);

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  // --- Team Pill Colors ---
  const teamColors = [
    "primary", "success", "warning", "info", "danger", "secondary",
  ];

  return (
    <div>
      {/* Header Section */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h4 className="m-0">
          Team Members <span className="user-count">{data.length} users</span>
        </h4>

        <div className="d-flex align-items-center gap-2">
          <InputGroup className="search-box">
            <Form.Control
              className="search-input"
              placeholder="Search..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <Button className="search-btn">
              <Search size={18} color="#6A37C4" />
            </Button>
          </InputGroup>

          {/* Filter */}
          <OverlayTrigger
            trigger="click"
            placement="bottom-end"
            rootClose
            overlay={
              <Popover id="filter-popover" className="filter-popover">
                <Popover.Body>
                  <FilterDropdown
                    roles={[...new Set(data.map((u) => u.role).filter(Boolean))]}
                    teams={[
                      ...new Set(
                        data.flatMap((u) =>
                          Array.isArray(u.teams) ? u.teams : [u.teams]
                        ).filter(Boolean)
                      ),
                    ]}
                    selectedRole={selectedRole}
                    selectedTeam={selectedTeam}
                    setSelectedRole={setSelectedRole}
                    setSelectedTeam={setSelectedTeam}
                  />

                  <div className="text-center mt-3">
                    <Button
                      variant="outline-danger"
                      className="clear-filters-btn"
                      onClick={() => {
                        setSelectedRole("");
                        setSelectedTeam("");
                      }}
                    >
                      Clear Filters
                    </Button>
                  </div>
                </Popover.Body>
              </Popover>
            }
          >
            <Button variant="outline-secondary" className="filter-btn">
              <Filter
                size={18}
                color={selectedRole || selectedTeam ? "#6A37C4" : "black"}
              />
            </Button>
          </OverlayTrigger>

          <Button className="add-user" onClick={() => handleShow()}>
            + Add Member
          </Button>
        </div>
      </div>

      {/* Loader */}
      {loading ? (
        <div className="d-flex justify-content-center py-5">
          <Spinner animation="border" />
        </div>
      ) : (
        <>
          {/* Table */}
          <Table responsive>
            <thead className="table-light">
              <tr>
                <th>Name</th>
                <th>Status</th>
                <th>Role</th>
                <th>Email</th>
                <th>Teams</th>
                <th>Gender</th>
                <th>Actions</th>
              </tr>
            </thead>

            <tbody>
              {currentUsers.map((user) => (
                <tr key={user.id}>
                  <td>
                    <div
                      className="d-flex align-items-center"
                      style={{ cursor: "pointer" }}
                      onClick={() => handleViewShow(user)}
                    >
                      <img
                        src={user.profileURL}
                        alt={user.name}
                        className="rounded-circle me-2 border border-2 border-primary"
                        style={{ width: "35px", height: "35px" }}
                      />
                      <div>
                        <div className="fw-bold text-dark">{user.name}</div>
                        <small className="text-muted">@{user.username}</small>
                      </div>
                    </div>
                  </td>
                  <td>
                    <StatusBadge status={user.status} />
                  </td>
                  <td>{user.role}</td>
                  <td>{user.email}</td>
                  <td>
  <div className="d-flex flex-wrap gap-1">
    {user.teams.map((team, i) => {
      const colorMap = {
        Design: { bg: "#E3F2FD", text: "#1565C0" }, // light blue
        Product: { bg: "#FFF3E0", text: "#EF6C00" }, // soft orange
        Marketing: { bg: "#F3E5F5", text: "#8E24AA" }, // lavender
        Engineering: { bg: "#E8F5E9", text: "#2E7D32" }, // mint green
        Research: { bg: "#FBE9E7", text: "#D84315" }, // coral
        Custom: { bg: "#E0E0E0", text: "#424242" }, // gray
      };

      const { bg, text } = colorMap[team] || {
        bg: "#ECEFF1",
        text: "#263238",
      };

      return (
        <span
          key={i}
          className="px-3 py-1 rounded-pill fw-semibold"
          style={{
            backgroundColor: bg,
            color: text,
            fontSize: "0.8rem",
          }}
        >
          {team}
        </span>
      );
    })}
  </div>
</td>

                  <td>{user.gender || "N/A"}</td>
                  <td className="d-flex gap-2 align-items-center">
                    <Button
                      variant="outline-primary"
                      size="sm"
                      onClick={() => handleEditShow(user)}
                    >
                      <Pen size={16} />
                    </Button>
                    <Button
                      variant="outline-danger"
                      size="sm"
                      onClick={() => handleDeleteShow(user)}
                    >
                      <Trash size={16} />
                    </Button>
                  </td>
                </tr>
              ))}

              {currentUsers.length === 0 && (
                <tr>
                  <td colSpan="7" className="text-center text-muted py-3">
                    No results found.
                  </td>
                </tr>
              )}
            </tbody>
          </Table>

          {/* Pagination */}
          {filteredData.length > itemsPerPage && (
            <div className="d-flex justify-content-center">
              <Pagination>
                <Pagination.Prev
                  onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                />
                {Array.from({ length: totalPages }).map((_, i) => (
                  <Pagination.Item
                    key={i}
                    active={currentPage === i + 1}
                    onClick={() => handlePageChange(i + 1)}
                  >
                    {i + 1}
                  </Pagination.Item>
                ))}
                <Pagination.Next
                  onClick={() =>
                    setCurrentPage((p) => Math.min(totalPages, p + 1))
                  }
                  disabled={currentPage === totalPages}
                />
              </Pagination>
            </div>
          )}
        </>
      )}

      {/* Add/Edit Modal */}
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>{editMode ? "Edit User" : "Add New User"}</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          <Form onSubmit={handleSave}>
            <Form.Group className="mb-3">
              <Form.Control
                placeholder="Enter Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Control
                placeholder="Enter Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Control
                placeholder="Enter Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
              >
                <option value="">Select Status</option>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
                <option value="Suspended">Suspended</option>
                <option value="Banned">Banned</option>
                <option value="Pending">Pending</option>
              </Form.Select>
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Select
                value={role}
                onChange={(e) => setRole(e.target.value)}
              >
                <option value="">Select Role</option>
                <option value="Product Designer">Product Designer</option>
                <option value="Product Manager">Product Manager</option>
                <option value="Frontend Developer">Frontend Developer</option>
                <option value="Fullstack Developer">Fullstack Developer</option>
                <option value="UX Designer">UX Designer</option>
                <option value="UX Copywriter">UX Copywriter</option>
                <option value="QA Engineer">QA Engineer</option>
                <option value="Custom">Custom</option>
              </Form.Select>
              {role === "Custom" && (
                <Form.Control
                  className="mt-2"
                  placeholder="Enter custom role"
                  onChange={(e) => setRole(e.target.value)}
                />
              )}
            </Form.Group>

            {/* Multi-Team Selector */}
            <Form.Group className="mb-3">
              <Form.Label>Select Teams</Form.Label>
              <Form.Select
                multiple
                value={teams}
                onChange={(e) =>
                  setTeams([...e.target.selectedOptions].map((opt) => opt.value))
                }
              >
                <option value="Design">Design</option>
                <option value="Product">Product</option>
                <option value="Marketing">Marketing</option>
                <option value="Engineering">Engineering</option>
                <option value="Research">Research</option>
                <option value="Custom">Custom</option>
              </Form.Select>
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Select
                value={gender}
                onChange={(e) => setGender(e.target.value)}
              >
                <option value="">Select Gender</option>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
              </Form.Select>
            </Form.Group>

            <Button type="submit" className="w-100 add-user">
              {editMode ? "Save Changes" : "Add User"}
            </Button>
          </Form>
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default People;
